---
title: DeviceFileCertificateInfo table in the advanced hunting schema
description: Learn about file signing information in the DeviceFileCertificateInfo table of the advanced hunting schema
search.appverid: met150
ms.service: defender-xdr
ms.subservice: adv-hunting
f1.keywords: 
  - NOCSH
ms.author: pauloliveria
author: poliveria
ms.localizationpriority: medium
manager: dansimp
audience: ITPro
ms.collection: 
- m365-security
- tier3
ms.custom: 
- cx-ti
- cx-ah
appliesto:
    - Microsoft Defender XDR
    - Microsoft Sentinel in the Microsoft Defender portal
ms.topic: reference
ms.date: 03/28/2025
---

# DeviceFileCertificateInfo

[!INCLUDE [Microsoft Defender XDR rebranding](../includes/microsoft-defender.md)]


The `DeviceFileCertificateInfo` table in the [advanced hunting](advanced-hunting-overview.md) schema contains information about file signing certificates. This table uses data obtained from certificate verification activities regularly performed on files on endpoints.

This advanced hunting table is populated by records from Microsoft Defender for Endpoint. If your organization hasn’t deployed the service in Microsoft Defender XDR, queries that use the table aren’t going to work or return any results. For more information about how to deploy Defender for Endpoint in Defender XDR, read [Deploy supported services](deploy-supported-services.md).

For information on other tables in the advanced hunting schema, [see the advanced hunting reference](advanced-hunting-schema-tables.md).

| Column name | Data type | Description |
|-------------|-----------|-------------|
| `Timestamp` | `datetime` | Date and time when the record was generated |
| `DeviceId` | `string` | Unique identifier for the device in the service |
| `DeviceName` | `string` | Fully qualified domain name (FQDN) of the device |
| `SHA1` | `string` | SHA-1 of the file that the recorded action was applied to |
| `IsSigned` | `bool` | Indicates whether the file is signed |
| `SignatureType` | `string` | Indicates whether signature information was read as embedded content in the file itself or read from an external catalog file |
| `Signer` | `string` | Information about the signer of the file |
| `SignerHash` | `string` | Unique hash value identifying the signer |
| `Issuer` | `string` | Information about the issuing certificate authority (CA) |
| `IssuerHash` | `string` | Unique hash value identifying issuing certificate authority (CA) |
| `CertificateSerialNumber` | `string` | Identifier for the certificate that is unique to the issuing certificate authority (CA) |
| `CrlDistributionPointUrls` | `string` |  JSON array listing the URLs of network shares that contain certificates and certificate revocation lists (CRLs) |
| `CertificateCreationTime` | `datetime` | Date and time the certificate was created |
| `CertificateExpirationTime` | `datetime` | Date and time the certificate is set to expire |
| `CertificateCountersignatureTime` | `datetime` | Date and time the certificate was countersigned |
| `IsTrusted` | `bool` | Indicates whether the file is trusted based on the results of the WinVerifyTrust function, which checks for unknown root certificate information, invalid signatures, revoked certificates, and other questionable attributes |
| `IsRootSignerMicrosoft` | `boolean` | Indicates whether the signer of the root certificate is Microsoft and if the file is included in Windows operating system |
| `ReportId` | `long` | Event identifier based on a repeating counter. To identify unique events, this column must be used in conjunction with the DeviceName and Timestamp columns. | 

## Related topics
- [Advanced hunting overview](advanced-hunting-overview.md)
- [Learn the query language](advanced-hunting-query-language.md)
- [Use shared queries](advanced-hunting-shared-queries.md)
- [Hunt across devices, emails, apps, and identities](advanced-hunting-query-emails-devices.md)
- [Understand the schema](advanced-hunting-schema-tables.md)
- [Apply query best practices](advanced-hunting-best-practices.md)
[!INCLUDE [Microsoft Defender XDR rebranding](../includes/defender-m3d-techcommunity.md)]
